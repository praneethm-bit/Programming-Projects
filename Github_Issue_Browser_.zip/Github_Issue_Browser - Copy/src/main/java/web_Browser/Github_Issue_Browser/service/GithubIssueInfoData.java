package web_Browser.Github_Issue_Browser.service;

import web_Browser.Github_Issue_Browser.format.GithubIssueInfo;
import web_Browser.Github_Issue_Browser.format.GithubUserInfo;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import org.json.*;

@Service
public class GithubIssueInfoData {
	
	private static String url = "https://api.github.com/repos/walmartlabs/thorax/issues";
    private List<GithubIssueInfo> Information_Collection = new ArrayList<>();
    private List<GithubUserInfo> User_Information = new ArrayList<>();
    /*public void set_Url(String organization, String repository) {
    	
    }*/
    public List<GithubIssueInfo> getAllIssues() {
        return Information_Collection;
    }

    public List<GithubUserInfo> getUserInfo(){
    	return User_Information;
    }
    @PostConstruct
    @Scheduled(cron = "* * 1 * * *")
    public void GetGitIssues() throws Exception, InterruptedException, IOException {
        List<GithubIssueInfo> retrieved_Information = new ArrayList<>();
        List<GithubUserInfo> User_Information = new ArrayList<>();
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        // optional default is GET
        con.setRequestMethod("GET");
        //add request header
        con.setRequestProperty("User-Agent", "Mozilla/5.0");
        int responseCode = con.getResponseCode();
        System.out.println("\nSending 'GET' request to URL : " + url);
        System.out.println("Response Code : " + responseCode);
        BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();
        while ((inputLine = in.readLine()) != null) {
        	response.append(inputLine);
        }
        in.close();
        JSONArray my_Response = new JSONArray(response.toString());
        System.out.println(my_Response.length());
        for (int i = 0; i < my_Response.length(); i++) {
        	GithubIssueInfo information_ = new GithubIssueInfo();
        	GithubUserInfo user_info = new GithubUserInfo();
       	 	JSONObject part_ = my_Response.getJSONObject(i);
            System.out.println("Title: " + part_.optString("title"));
            System.out.println("Issue number: "+ part_.optLong("number"));
            System.out.println("State: " + part_.optBoolean("state"));
            information_.setTitle_(part_.optString("title"));
            information_.setIssue_num_(part_.optLong("number"));
            information_.setState_(part_.optBoolean("state"));
            
            JSONObject obj_ = new JSONObject(part_.optString("user"));
            System.out.println("User ID: " + obj_.optLong("id"));
            user_info.setUser_id(obj_.optLong("id"));
            user_info.setUser_name(obj_.optString("login"));
            user_info.setUser_URL(obj_.optString("html_url"));
            user_info.setAdmin(obj_.optBoolean("site_admin"));
            retrieved_Information.add(information_);
            User_Information.add(user_info);
        }
        this.Information_Collection = retrieved_Information;
        this.User_Information = User_Information;
        
      }
}
