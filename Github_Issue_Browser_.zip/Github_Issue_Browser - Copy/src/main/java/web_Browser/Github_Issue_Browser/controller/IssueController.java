package web_Browser.Github_Issue_Browser.controller;

import web_Browser.Github_Issue_Browser.format.GithubIssueInfo;
import web_Browser.Github_Issue_Browser.service.GithubIssueInfoData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class IssueController {
	
	 @Autowired
	    GithubIssueInfoData GithubIssueInfoData_;

	    @GetMapping("/")
	    public String issue(Model model) {
	        List<GithubIssueInfo> Information_Collection = GithubIssueInfoData_.getAllIssues();
	        
	        model.addAttribute("Information_Collection", Information_Collection);

	        return "issue";
	    }
	
}
