package web_Browser.Github_Issue_Browser.format;

public class GithubUserInfo {
	private Long user_id;
	private String user_name;
	private String user_URL;
	private boolean admin;
	public Long getUser_id() {
		return user_id;
	}
	public void setUser_id(Long user_id) {
		this.user_id = user_id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	@Override
	public String toString() {
		return "GithubUserInfo [user_id=" + user_id + ", user_name=" + user_name + ", user_URL=" + user_URL + ", admin="
				+ admin + "]";
	}
	public String getUser_URL() {
		return user_URL;
	}
	public void setUser_URL(String user_URL) {
		this.user_URL = user_URL;
	}
	public boolean isAdmin() {
		return admin;
	}
	public void setAdmin(boolean admin) {
		this.admin = admin;
	}
}
