package web_Browser.Github_Issue_Browser.format;

public class GithubIssueInfo {
	
	private String title_;
	
	private Long issue_num_;
	
	private boolean state_;
	
	public String getTitle_() {
		return title_;
	}
	
	public void setTitle_(String title_) {
		this.title_ = title_;
	}
	
	public Long getIssue_num_() {
		return issue_num_;
	}
	
	public void setIssue_num_(Long issue_num_) {
		this.issue_num_ = issue_num_;
	}
	
	public boolean isState_() {
		return state_;
	}
	
	public void setState_(boolean state_) {
		this.state_ = state_;
	}
	
	 @Override
	 public String toString() {
	        return "GithubIssueInfo {" +
	                "title ='" + title_ + '\'' +
	                ", issue number ='" + issue_num_ + '\'' +
	                ", state =" + state_ +
	                '}';
	 }
	 
}
