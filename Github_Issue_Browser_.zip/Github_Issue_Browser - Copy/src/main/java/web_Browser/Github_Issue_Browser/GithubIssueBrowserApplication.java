package web_Browser.Github_Issue_Browser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class GithubIssueBrowserApplication {

	public static void main(String[] args) {
		SpringApplication.run(GithubIssueBrowserApplication.class, args);
	}

}
