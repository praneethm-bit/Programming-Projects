package web_Browser.Github_Issue_Browser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GithubIssueBrowserApplicationTests {

	@Test
	void contextLoads() {
	}

}